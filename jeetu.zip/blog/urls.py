from django.urls import path
from . import views

urlpatterns = [
    path('', views.blog, name="blog"),
    path('blogs/comment', views.postComment, name="postComment"),
    path('blog/<str:slug>', views.home, name="home"),
    path('contactus/', views.Contactus, name="contactus"),
    path('about/', views.about, name="about"),
    path('blog/category/<str:category>', views.categoryposts, name="categoryposts")
]